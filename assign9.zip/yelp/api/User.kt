package com.example.yelp.api

data class User(
    val id: String,
    val image_url: String,
    val name: String,
    val profile_url: String
)