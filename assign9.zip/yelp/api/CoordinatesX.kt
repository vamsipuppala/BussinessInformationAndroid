package com.example.yelp.api

data class CoordinatesX(
    val latitude: Double,
    val longitude: Double
)