package com.example.yelp.api

data class Category(
    val alias: String,
    val title: String
)