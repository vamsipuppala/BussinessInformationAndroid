package com.example.yelp.api

class temp : ArrayList<Double>()