package com.example.yelp.api

data class CategoryX(
    val alias: String,
    val title: String
)