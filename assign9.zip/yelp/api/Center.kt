package com.example.yelp.api

data class Center(
    val latitude: Double,
    val longitude: Double
)