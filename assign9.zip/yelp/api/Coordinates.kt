package com.example.yelp.api

data class Coordinates(
    val latitude: Double,
    val longitude: Double
)