package com.example.yelp.api

data class Region(
    val center: Center
)